var button = document.querySelectorAll("#button");
var menu = document.getElementsByClassName("overlay");
var buttonWasClicked = false;

var openMenu = function() {
    alert("Hello"); 
    menu.classList.add("showMenu");
};